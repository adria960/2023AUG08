package com.example.demoawscore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoAwsCoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoAwsCoreApplication.class, args);
	}

}
