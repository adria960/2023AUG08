-- Put single quotes
-- authority is USER or ADMIN. In Java class it is USER or ADMIN
insert into users (username, password, enabled) values ('user', 'pass', true);

insert into users (username, password, enabled) values ('admin', 'pass', true);

insert into authorities (username, authority) values ('user', 'USER');

insert into authorities (username, authority) values ('admin', 'ADMIN');