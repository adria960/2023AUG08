package io.javabrains.springsecurityh2jdbc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityH2JdbcApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityH2JdbcApplication.class, args);
	}

}
