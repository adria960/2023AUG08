package io.javabrains.springcsecurityjdbc.springcsecurityjdbc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCsecurityJdbcApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCsecurityJdbcApplication.class, args);
	}

}
