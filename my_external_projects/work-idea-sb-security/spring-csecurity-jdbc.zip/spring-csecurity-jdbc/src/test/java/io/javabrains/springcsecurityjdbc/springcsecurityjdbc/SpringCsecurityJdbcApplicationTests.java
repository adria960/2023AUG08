package io.javabrains.springcsecurityjdbc.springcsecurityjdbc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCsecurityJdbcApplicationTests {

	@Test
	void contextLoads() {
	}

}
