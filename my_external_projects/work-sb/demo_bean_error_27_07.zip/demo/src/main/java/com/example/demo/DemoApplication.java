package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class DemoApplication {
		//implements CommandLineRunner {

//	@Autowired
//	private ApplicationContext applicationContext;

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

	/*
	@Override
	public void run(String... args) throws Exception {

		System.out.println("getDisplayName: " + applicationContext.getDisplayName().toString());
		System.out.println("getId: " + applicationContext.getId());
		System.out.println("getApplicationName: " + applicationContext.getApplicationName());

		//MyBean myBean = applicationContext.getBean(MyBean.class);
		//System.out.println(myBean.getApplicationId());
	}
	 */
}
